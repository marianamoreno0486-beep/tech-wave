# Tech Wave

Sitio web estático para GitHub Pages.

## Publicar
1. Sube los archivos a GitHub.
2. Ve a Settings > Pages.
3. Selecciona Deploy from Branch.
4. Elige main y root.
