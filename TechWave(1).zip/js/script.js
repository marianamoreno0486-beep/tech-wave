
document.querySelector('form').addEventListener('submit',e=>{
e.preventDefault();
alert('Gracias por contactar a Tech Wave');
});
